# 2026 Washington August Primary endorsement consensus guide

Release `2026-primary.11` packages the public HTML guide with its canonical JSON, CSV,
review, validation, provenance, build, and release manifests.

## Audit identity

- Data as of: 2026-08-05T00:00:00+00:00
- Built at: 2026-11-07T11:57:06-08:00
- Code revision: `ccce7f3f0285e39bb541d7e2984e36b8e92e1595`
- Source panel: `wa-2026-primary-default-sources-v4`
- Source panel hash: `389a978b149da9afdb919fdb9dfd1d4d3fbecc290d3b1cd41da3e3fd363de0b5`
- Reviewed source extracts: 41 of 43 active sources
- Displayed source decisions: 538
- Unresolved review items: 0

## Source access and discovery failures

These counts describe the canonical release inputs, not the latest recurring source-access observations. ‘None’ in this section does not establish current successful access or recovery. Later access failures retain the latest verified endorsement evidence; additions, changes and withdrawals still require normal review.

- `washington-state-democrats`: access_restricted — Direct unattended access remains blocked and a fresh official-domain search found no 2026 endorsement roster; candidate and third-party lists were not substituted for a party publication.
- `environmental-climate-caucus-wa-democrats`: not_found — The official page documents the 2026 endorsement process and voting dates but publishes no candidate decisions; no separate 2026 endorsed-candidate roster was located.

## Known limitations

- 2 active sources had access or discovery failures.
- 32 displayed races have incomplete source coverage.

Missing coverage is not counted as opposition. The guide aggregates selected organizations'
endorsements; it is not an official voter pamphlet or independent candidate evaluation. Full
third-party page captures are excluded. Every included decision is backed by a permitted,
content-addressed structured extract and a public official URL.

## Software changes

## 2026-primary.11 — 2026-11-07

### Added

- Filter general-election contests by precinct (#634)
- Follow November ballot contest order (#649)
- Keep Guide Sources and filters in one sticky group (#681)
- Keep compact ballot controls attached and independent (#674)
- Make Updates an election-information log (#680)
- Publish reviewed hourly preliminary-results refreshes (#699)
- Show unofficial election-wide preliminary results (#698)
- Support source refresh intervals (#653)
- Unify precinct and voting address search (#660)

### Documentation

- Adopt recurring source checks (#656)
- Prepare district setup delivery history for issue 608 (#632)
- Record approved SEIU adoption exception and baseline status (#633)

### Fixed

- Accept completed responses and record manual source reviews (#638)
- Add SGN Supreme Court endorsements and retain verification evidence (#670)
- Allow release evidence on owning pull requests (#645)
- Finish historical verification dispositions and strict probe fixture (#643)
- Keep minor copy edits out of public Updates (#664)
- Publish unchanged verification refreshes (#702)
- Report access failures without discarding verified evidence (#648)
- Retain safe fetch diagnostics and current reviews (#654)
- Simplify status badges and move timestamps below tallies (#703)
- Update general-election page subheadings (#662)

### Other

- Admit bounded November 3 verification reviews (#686)
- Bump npm dependency tooling and prepare General 72 (#683)
- Keep Ballot filters usable within the selected precinct (#669)
- Record three completed November 3 source reviews (#689)
- Restore address resolution after reviewed County context refresh (#694)
- Unify selection menu styling across Guide and Comparisons (#672)
- Admit three SGN initiative endorsements and October 27 verification records (#650)
- Record completed public source follow-ups and late manual reviews (#641)

### Performance

- Isolate unit checks and shorten verification feedback (#652)

### Tooling

- Activate verified primary archive for #607 (#631)
- Approve October 25 factual verification baselines (#629)
- Continue dropdown styling delivery with startup diagnostics (#697)
- Prepare verified preliminary results refresh (#700)
- Prepare verified preliminary results refresh (#701)
- Record October 28 verification reviews (#658)
- Record six supplied endorsement snapshots (#642)
- Retain November 3 first-count captures
- Retain endorsement verification evidence (#666)
- Review October 26 verification baselines (#635)
- Update JavaScript and Python tooling (#639)
- Update Python dependencies and prepare General 71

